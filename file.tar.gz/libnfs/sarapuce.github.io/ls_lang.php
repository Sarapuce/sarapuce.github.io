<?php
$output = shell_exec('ls');
echo "<pre>$output</pre>";
?>
