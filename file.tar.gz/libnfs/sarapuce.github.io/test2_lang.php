<?php
print(base64_encode(file_get_contents('./index.php')));
 ?>
