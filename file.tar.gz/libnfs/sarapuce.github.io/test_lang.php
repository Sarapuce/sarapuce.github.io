<?php
$output = shell_exec('ls -la');
echo "<pre>$output</pre>";
?>
