<?php
print_r(scandir('.'));
?>
